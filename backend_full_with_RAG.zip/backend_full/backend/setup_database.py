"""
One-time setup: creates the database (if it doesn't exist) and all tables
defined in app/models.py.

Usage (from backend/ root, venv active):
    python setup_database.py
"""
import pymysql
from app.database import engine, Base, DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME
from app import models  # noqa: F401  (import registers models with Base)


def create_database_if_not_exists():
    conn = pymysql.connect(
        host=DB_HOST,
        port=int(DB_PORT),
        user=DB_USER,
        password=DB_PASSWORD,
    )
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                f"CREATE DATABASE IF NOT EXISTS `{DB_NAME}` "
                f"CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
            )
        conn.commit()
        print(f"Database '{DB_NAME}' ready.")
    finally:
        conn.close()


def create_tables():
    Base.metadata.create_all(bind=engine)
    print("All tables created (or already existed):")
    for table in Base.metadata.sorted_tables:
        print(f"  - {table.name}")


if __name__ == "__main__":
    create_database_if_not_exists()
    create_tables()
    print("\nDatabase setup complete.")
