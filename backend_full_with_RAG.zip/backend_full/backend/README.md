# ZeAI Soft Chatbot — Backend + API + Database + RAG (Integrated)

## What's in here

- **API**: FastAPI app (`app/main.py`) — chat, sessions, admin auth, FAQ CRUD, analytics
- **Database**: MySQL via SQLAlchemy (`app/models.py`, `app/database.py`)
- **FAQ matching**: keyword-overlap search against the MySQL `faqs` table (`app/services/faq_matcher.py`)
- **RAG**: ChromaDB + Groq document retrieval, used when no confident FAQ match is found (`app/services/rag_placeholder.py`, `app/services/rag/`)

## Request flow

```
POST /chat
   |
   v
find_faq_match() -- searches MySQL `faqs` table
   |
   +-- confident match --> return FAQ answer
   |
   +-- no match --> get_rag_response()
                        |
                        v
                  Search ChromaDB 'documents' collection
                        |
                        +-- score >= 0.35 --> top 5 chunks -> Groq -> answer
                        |
                        +-- score <  0.35 --> "I'm only able to answer
                                               questions related to ZeAI Soft."
```

Every response gets logged to `chat_history` regardless of source.

## Setup (run in order)

1. **Install dependencies**
   ```
   cd backend
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   ```

2. **Check `.env`** — already filled in with the DB credentials you gave me:
   ```
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_USER=root
   DB_PASSWORD=Moni@2004
   DB_NAME=zeai_soft_chatbot
   JWT_SECRET_KEY=change_this_to_a_long_random_secret_string
   GROQ_API_KEY=your_groq_api_key_here
   ```
   Replace `GROQ_API_KEY` with your real key, and ideally replace `JWT_SECRET_KEY`
   with a random string (used to sign admin login tokens).

   Security note: this `.env` has a real DB password in it — don't commit it to
   git or share it publicly. `.gitignore` in this repo should already exclude `.env`.

3. **Create the database and tables** (safe to re-run, won't duplicate tables):
   ```
   python setup_database.py
   ```
   This creates the `zeai_soft_chatbot` database if it doesn't exist, then
   creates all tables from `app/models.py` (admin, categories, faqs,
   chat_history, knowledge_base, user_sessions).

4. **Seed starter FAQs into MySQL** (safe to re-run, skips duplicates):
   ```
   python seed_faqs.py
   ```
   Loads 25 FAQs covering internships, training, hackathon, services, and
   company info directly into the `faqs` table.

5. **Build the RAG document collection**:
   ```
   python -m app.services.rag.ingest
   ```
   Reads the 4 .docx files in `app/services/rag/data/`, chunks them, embeds
   them, and stores them in `app/services/rag/chroma_db/`. Add
   `company_policies.docx` and `zeai_booklet.docx` here later and re-run this
   step when they're ready.

6. **Create an admin account** (needed to log in and use admin endpoints).
   Use `generate_hash.py` to hash a password, then insert an admin row —
   check that script for usage, or ask if you want a ready-made script for this.

7. **Run the API**:
   ```
   uvicorn app.main:app --reload
   ```
   Visit `http://127.0.0.1:8000/docs` for interactive API docs.

## Testing /chat

1. Start a session:
   ```
   POST /session/start
   ```
   Returns a `session_id` — use it in the next call.

2. Ask a question:
   ```
   POST /chat
   {
     "session_id": 1,
     "query": "how do I apply for the internship?"
   }
   ```
   FAQ questions return instantly from MySQL. Document-specific questions
   (not covered by an FAQ) get routed to RAG and answered from your .docx
   files via Groq. Unrelated questions get the fallback message.

## Notes / tuning

- `DOC_THRESHOLD = 0.35` in `rag_placeholder.py` controls how confident a
  document match must be before calling Groq. Lower it if good questions are
  falling back too often; raise it if irrelevant questions are getting
  answered.
- FAQ matching in `faq_matcher.py` requires at least 2 overlapping
  significant words (len > 3) between the query and an FAQ question — this
  is simple keyword matching, not embeddings, so exact phrasing matters more
  than with the RAG side.
- Re-run `python -m app.services.rag.ingest` any time documents change.
- Re-run `python seed_faqs.py` any time you add new FAQs to the `FAQS` list
  in that file (or add them via the `/admin/faqs` API once an admin account
  exists).
