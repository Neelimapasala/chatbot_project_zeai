from app.database import SessionLocal
from app import models
 
FAQS = [
    ("What is the ZeAI Soft Internship Program?",
     "The ZeAI Soft Internship Program provides students and fresh graduates with hands-on experience through real-world projects under mentor guidance."),
    ("Who can apply for the internship?",
     "Students, fresh graduates, and aspiring professionals interested in technology can apply based on the eligibility criteria."),
    ("Is the internship paid?",
     "The availability of a stipend depends on the internship offer. Please refer to the current internship announcement for details."),
    ("Will I receive an internship certificate?",
     "Yes. Eligible interns receive an Internship Completion Certificate after successfully completing the internship requirements."),
    ("Can the internship lead to a full-time job?",
     "Outstanding interns may be considered for placement opportunities based on their performance and company requirements."),
    ("What is the ZeAI Soft Training Program?",
     "The ZeAI Soft Training Program is a structured learning program that combines technical training, practical assignments, mentorship, and industry-oriented projects."),
    ("What is the Train & Deploy Model?",
     "The Train & Deploy Model is a three-phase learning pathway consisting of Corporate Training, Internship, and Placement Opportunity."),
    ("Which learning domains are available?",
     "ZeAI Soft offers AI Engineering, Data Science, Full Stack Development, Cloud Engineering, Software Development, Quality Assurance, Business Analysis, Data Analytics, HR Operations, and Project Management."),
    ("Is the training available online or offline?",
     "Training programs are offered in Online, Offline, and Hybrid modes depending on the program."),
    ("Will I receive a training certificate?",
     "Yes. Participants who successfully complete the training requirements are eligible for a Training Completion Certificate."),
    ("What is the Made in India 2026 Hackathon?",
     "The Made in India 2026 Hackathon is ZeAI Soft's national innovation challenge focused on solving real-world problems through technology and innovation."),
    ("Who can participate in the hackathon?",
     "Students, developers, designers, innovators, and early-stage entrepreneurs who meet the eligibility criteria can participate."),
    ("How do I register for the hackathon?",
     "You can register through the official hackathon registration page during the registration period."),
    ("What are the prizes for the winners?",
     "The hackathon offers a total prize pool of \u20b910,00,000, and the grand prize includes a fully sponsored 7-day trip to Malaysia."),
    ("Will participants receive certificates?",
     "Yes. Eligible participants receive certificates, and top performers receive additional recognition and opportunities."),
    ("What services does ZeAI Soft provide?",
     "ZeAI Soft provides AI solutions, software development, cloud services, consulting, training programs, internships, and technology solutions."),
    ("Does ZeAI Soft develop AI solutions?",
     "Yes. ZeAI Soft develops Artificial Intelligence and Machine Learning solutions tailored to business requirements."),
    ("Does ZeAI Soft provide cloud services?",
     "Yes. ZeAI Soft offers cloud consulting, migration, deployment, and cloud-based application development services."),
    ("Can businesses request custom software development?",
     "Yes. ZeAI Soft develops customized software solutions based on client requirements and business objectives."),
    ("How can I contact ZeAI Soft for business inquiries?",
     "You can contact ZeAI Soft through its official website or by emailing info@zeaisoft.com."),
    ("Where is ZeAI Soft located?",
     "ZeAI Soft operates in Tamil Nadu, India, with its working office located in Chennai."),
    ("What are the company working hours?",
     "The standard working hours are Monday to Friday, from 9:00 AM to 6:00 PM."),
    ("How can I contact ZeAI Soft?",
     "You can contact ZeAI Soft through its official website or by emailing info@zeaisoft.com."),
    ("Does ZeAI Soft provide internships and training?",
     "Yes. ZeAI Soft offers structured training programs, internships, mentorship, and career development opportunities."),
    ("How can I stay updated about new programs and events?",
     "Follow ZeAI Soft's official website and social media channels for the latest announcements about internships, training programs, hackathons, and events."),
]
 
 
def get_or_create_default_category(db):
    category = db.query(models.Category).filter(models.Category.name == "General").first()
    if category:
        return category
 
    category = models.Category(
        name="General",
        description="Default category for general FAQs",
    )
    db.add(category)
    db.commit()
    db.refresh(category)
    return category
 
 
def seed():
    db = SessionLocal()
    try:
        default_category = get_or_create_default_category(db)
 
        existing = {faq.question for faq in db.query(models.FAQ).all()}
        added = 0
        for question, answer in FAQS:
            if question in existing:
                continue
            db.add(models.FAQ(
                category_id=default_category.category_id,
                question=question,
                answer=answer,
                display_order=added,
            ))
            added += 1
        db.commit()
        print(f"Added {added} new FAQs ({len(FAQS) - added} already existed, skipped).")
    finally:
        db.close()
 
 
if __name__ == "__main__":
    seed()