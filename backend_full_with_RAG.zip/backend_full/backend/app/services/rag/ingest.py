"""
Run this once (and again whenever docs in data/ change) to build the
document vector store used by get_rag_response() in rag_placeholder.py.

Usage (from backend/ root, with venv active):
    python -m app.services.rag.ingest
"""
import os
from langchain_community.document_loaders import Docx2txtLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(THIS_DIR, "data")
CHROMA_DIR = os.path.join(THIS_DIR, "chroma_db")
DOC_COLLECTION = "documents"


def load_documents():
    docs = []
    if not os.path.exists(DATA_DIR):
        raise FileNotFoundError(f"'{DATA_DIR}' not found. Add your .docx files there.")

    for filename in os.listdir(DATA_DIR):
        if filename.endswith(".docx"):
            path = os.path.join(DATA_DIR, filename)
            loader = Docx2txtLoader(path)
            loaded = loader.load()
            for d in loaded:
                d.metadata["source"] = filename
            docs.extend(loaded)
            print(f"Loaded: {filename}")

    if not docs:
        raise ValueError(f"No .docx files found in '{DATA_DIR}'.")
    return docs


def chunk_documents(docs):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=50,
        separators=["\n\n", "\n", ". ", " ", ""]
    )
    chunks = splitter.split_documents(docs)
    print(f"Created {len(chunks)} chunks")
    return chunks


def build_vectorstore(chunks):
    print("Loading embedding model...")
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory=CHROMA_DIR,
        collection_name=DOC_COLLECTION,
        collection_metadata={"hnsw:space": "cosine"}
    )
    print(f"Stored {len(chunks)} chunks in '{CHROMA_DIR}' (collection: {DOC_COLLECTION})")


if __name__ == "__main__":
    print("Starting document ingestion...\n")
    documents = load_documents()
    chunks = chunk_documents(documents)
    build_vectorstore(chunks)
    print("\nIngestion complete.")
