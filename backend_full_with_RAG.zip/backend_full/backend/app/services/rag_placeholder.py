import os
from functools import lru_cache
from dotenv import load_dotenv
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate

load_dotenv()

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
CHROMA_DIR = os.path.join(THIS_DIR, "rag", "chroma_db")
DOC_COLLECTION = "documents"

DOC_THRESHOLD = 0.35  # tuned for all-MiniLM-L6-v2; see rag/ingest.py for build details
TOP_K_DOCS = 5

GROQ_API_KEY = os.getenv("GROQ_API_KEY")

FALLBACK_MESSAGE = "I'm only able to answer questions related to ZeAI Soft."

PROMPT_TEMPLATE = """You are a helpful customer support assistant for ZeAI Soft.
Answer the user's question using ONLY the context provided below.
If the context does not fully answer the question, say what you can from the context
and suggest the user contact ZeAI Soft at info@zeaisoft.com or +91-9787-63-6374 for more details.
Do not make up information. Be concise and friendly.

Context:
{context}

Question:
{question}

Answer:"""


@lru_cache(maxsize=1)
def _get_embeddings():
    return HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")


@lru_cache(maxsize=1)
def _get_vectorstore():
    return Chroma(
        persist_directory=CHROMA_DIR,
        embedding_function=_get_embeddings(),
        collection_name=DOC_COLLECTION,
    )


@lru_cache(maxsize=1)
def _get_llm():
    if not GROQ_API_KEY:
        raise ValueError("GROQ_API_KEY not set. Add it to backend/.env")
    return ChatGroq(
        groq_api_key=GROQ_API_KEY,
        model_name="llama-3.3-70b-versatile",
        temperature=0.2,
    )


def get_rag_response(user_query: str) -> str:
    """
    Real RAG implementation, called from /chat in main.py whenever
    find_faq_match() (MySQL FAQ lookup) does not find a confident match.

    Flow: embed query -> search ChromaDB 'documents' collection ->
    if best relevance score >= DOC_THRESHOLD, retrieve top 5 chunks and
    send to Groq for a grounded answer; otherwise return a safe fallback.
    """
    try:
        vectordb = _get_vectorstore()
        results = vectordb.similarity_search_with_relevance_scores(user_query, k=TOP_K_DOCS)
    except Exception as e:
        return f"The knowledge base isn't available right now ({e}). Please try again shortly."

    if not results:
        return FALLBACK_MESSAGE

    best_score = results[0][1]
    if best_score < DOC_THRESHOLD:
        return FALLBACK_MESSAGE

    context = "\n\n".join(doc.page_content for doc, _ in results)

    try:
        llm = _get_llm()
        prompt = ChatPromptTemplate.from_template(PROMPT_TEMPLATE)
        chain = prompt | llm
        response = chain.invoke({"context": context, "question": user_query})
        return response.content
    except Exception as e:
        return f"I found relevant info but couldn't generate a response right now ({e})."
