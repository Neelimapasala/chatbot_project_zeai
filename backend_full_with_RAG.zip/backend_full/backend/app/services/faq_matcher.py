import re
from sqlalchemy.orm import Session
from app import models
 
 
def clean_words(text: str) -> set:
    """Lowercase, strip punctuation, and keep only significant words (len > 3)."""
    text = re.sub(r'[^\w\s]', '', text.lower())
    return set(w.strip() for w in text.split() if len(w) > 3)
 
 
def find_faq_match(db: Session, user_query: str):
    query_words = clean_words(user_query)
 
    if not query_words:
        return None
 
    faqs = db.query(models.FAQ).filter(models.FAQ.status == "active").all()
 
    best_match = None
    best_score = 0
 
    for faq in faqs:
        question_words = clean_words(faq.question)
        score = len(query_words & question_words)
        if score > best_score:
            best_score = score
            best_match = faq
 
    return best_match if best_score >= 2 else None