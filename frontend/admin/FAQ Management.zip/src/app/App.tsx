import { useState } from "react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import zeaiLogo from "@/imports/zeaisoft_logo.jpg";
import {
  LayoutDashboard, MessageSquareText, BookOpen, Building2,
  MessageCircle, BarChart2, Settings, Bell, Search, Plus,
  Pencil, Trash2, ChevronLeft, ChevronRight, HelpCircle,
  CheckCircle2, FileText, Archive, User, Menu, X,
} from "lucide-react";

// ── Palette ────────────────────────────────────────────────────────────────
const C = {
  bg:          "#D0BDF4",
  bgAlt:       "#DCCEF8",
  panel:       "#FFFFFF",
  panelSolid:  "#F6F0FE",
  border:      "rgba(91,33,182,0.16)",
  borderStrong:"rgba(91,33,182,0.4)",
  purple:      "#8B5CF6",
  purpleLight: "#7C3AED",
  purpleDark:  "#5B21B6",
  cyan:        "#0891B2",
  pink:        "#DB2777",
  text:        "#241B3D",
  textMuted:   "#6B6480",
  textFaint:   "#8F86A8",
  success:     "#059669",
  warning:     "#D97706",
  danger:      "#DC2626",
};

const NAV_ITEMS = [
  { label: "Dashboards",        icon: LayoutDashboard },
  { label: "FAQ Management",    icon: MessageSquareText },
  { label: "Knowledge Base",    icon: BookOpen },
  { label: "Company Information", icon: Building2 },
  { label: "Chat history",      icon: MessageCircle },
  { label: "Analytics",         icon: BarChart2 },
  { label: "Settings",          icon: Settings },
];

const CATEGORY_STYLES: Record<string, { bg: string; text: string }> = {
  General:       { bg: "rgba(8,145,178,0.12)",  text: C.cyan },
  Services:      { bg: "rgba(139,92,246,0.12)", text: C.purple },
  "AI Solutions":{ bg: "rgba(91,33,182,0.12)",  text: C.purpleDark },
  Internship:    { bg: "rgba(217,119,6,0.12)",  text: C.warning },
  Training:      { bg: "rgba(219,39,119,0.12)", text: C.pink },
};

const CATEGORY_BORDER: Record<string, string> = {
  General:       C.cyan,
  Services:      C.purple,
  "AI Solutions":C.purpleDark,
  Internship:    C.warning,
  Training:      C.pink,
};

const CATEGORY_PILL_STYLE: Record<string, { bg: string; text: string; border: string }> = {
  General:       { bg: "rgba(8,145,178,0.10)",  text: C.cyan,      border: "rgba(8,145,178,0.3)" },
  Services:      { bg: "rgba(139,92,246,0.10)", text: C.purple,    border: "rgba(139,92,246,0.3)" },
  "AI Solutions":{ bg: "rgba(91,33,182,0.10)",  text: C.purpleDark,border: "rgba(91,33,182,0.3)" },
  Internship:    { bg: "rgba(217,119,6,0.10)",  text: C.warning,   border: "rgba(217,119,6,0.3)" },
  Training:      { bg: "rgba(219,39,119,0.10)", text: C.pink,      border: "rgba(219,39,119,0.3)" },
};

const FAQS = [
  { question: "What is ZeAI Soft?",                           category: "General",      preview: "ZeAI Soft is a technology company specializing in Artificial Intelligence solution...", updated: "May 20, 2025", status: "Active" },
  { question: "What services does ZeAI Soft provide?",        category: "Services",     preview: "ZeAI Soft offers AI solutions, chatbot development, web and mobile application...",   updated: "May 18, 2025", status: "Active" },
  { question: "What AI solutions does ZeAI Soft offer?",      category: "AI Solutions", preview: "ZeAI Soft develops AI-powered chatbots, intelligent automation solutions, ma...",       updated: "May 16, 2025", status: "Active" },
  { question: "How can I apply for an internship at ZeAI Soft?", category: "Internship",preview: "You can apply by submitting your application through the official recruitment p...",    updated: "May 14, 2025", status: "Active" },
  { question: "What are the eligibility criteria for internships?", category: "Internship", preview: "Students pursuing undergraduate or postgraduate degrees with an interest in...",    updated: "May 12, 2025", status: "Active" },
  { question: "What is the duration of the internship program?",   category: "Internship", preview: "Internship durations vary depending on the program and project requirements...",     updated: "May 10, 2025", status: "Active" },
  { question: "Are internships paid or unpaid?",               category: "Internship",   preview: "Internship benefits vary depending on the specific program. Please refer to th...",   updated: "May 8, 2025",  status: "Draft"  },
  { question: "Does ZeAI Soft provide internship certificates?",category: "Internship",  preview: "Yes. Interns who successfully complete the internship program receive a certifi...",   updated: "May 6, 2025",  status: "Active" },
  { question: "What training programs are offered by ZeAI Soft?", category: "Training",  preview: "ZeAI Soft provides training in Artificial Intelligence, Machine Learning, Python...",  updated: "May 4, 2025",  status: "Active" },
  { question: "How can I enroll in a training program?",       category: "Training",     preview: "You can enroll by visiting the official website or registering through the officia...", updated: "May 2, 2025",  status: "Active" },
];

const CATS = ["All Categories", "General", "Services", "AI Solutions", "Internship", "Training"];

export default function App() {
  const [activeNav, setActiveNav]   = useState("FAQ Management");
  const [search, setSearch]         = useState("");
  const [category, setCategory]     = useState("All Categories");
  const [currentPage, setCurrentPage] = useState(1);
  const [menuOpen, setMenuOpen]     = useState(false);

  const filtered = FAQS.filter((f) => {
    const ms = f.question.toLowerCase().includes(search.toLowerCase()) || f.preview.toLowerCase().includes(search.toLowerCase());
    const mc = category === "All Categories" || f.category === category;
    return ms && mc;
  });

  return (
    <div className="min-h-screen flex flex-col" style={{ background: C.bg, fontFamily: "'Inter', sans-serif", color: C.text }}>

      {/* ── Nav ── */}
      <nav style={{ background: C.panel, borderBottom: `1px solid ${C.border}` }} className="sticky top-0 z-40">
        <div className="flex items-center h-14 px-4 md:px-6 gap-2">

          <button className="md:hidden p-1.5 rounded-md transition-colors shrink-0"
            style={{ color: C.textMuted }}
            onClick={() => setMenuOpen(true)}>
            <Menu size={20} />
          </button>

          <div className="flex items-center shrink-0 mr-2 md:mr-6">
            <ImageWithFallback src={zeaiLogo} alt="ZeAI Soft" className="h-8 md:h-9 w-auto object-contain" />
          </div>

          <div className="hidden md:flex items-center gap-0.5 overflow-x-auto flex-1 hide-scrollbar">
            {NAV_ITEMS.map(({ label, icon: Icon }) => {
              const active = activeNav === label;
              return (
                <button key={label} onClick={() => setActiveNav(label)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium whitespace-nowrap transition-colors"
                  style={{
                    background: active ? C.bgAlt : "transparent",
                    color: active ? C.purpleDark : C.textMuted,
                  }}>
                  <Icon size={14} />
                  {label}
                </button>
              );
            })}
          </div>

          <div className="flex-1 md:hidden" />

          <div className="flex items-center gap-2 md:gap-3 shrink-0 ml-2 md:ml-4">
            <button className="relative transition-colors" style={{ color: C.textFaint }}>
              <Bell size={18} />
              <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full" style={{ background: C.danger }} />
            </button>
            <div className="flex items-center gap-1.5 cursor-pointer">
              <div className="w-7 h-7 rounded-full flex items-center justify-center" style={{ background: C.purple }}>
                <User size={14} className="text-white" />
              </div>
              <span className="hidden sm:block text-sm font-medium" style={{ color: C.text }}>Admin</span>
            </div>
          </div>
        </div>
      </nav>

      {/* ── Mobile Drawer ── */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/30" onClick={() => setMenuOpen(false)} />
          <div className="absolute left-0 top-0 h-full w-72 flex flex-col shadow-2xl" style={{ background: C.panel }}>
            <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: `1px solid ${C.border}` }}>
              <ImageWithFallback src={zeaiLogo} alt="ZeAI Soft" className="h-8 w-auto object-contain" />
              <button onClick={() => setMenuOpen(false)} className="p-1.5 rounded-md transition-colors" style={{ color: C.textMuted }}>
                <X size={18} />
              </button>
            </div>
            <nav className="flex flex-col gap-1 p-3 flex-1 overflow-y-auto">
              {NAV_ITEMS.map(({ label, icon: Icon }) => {
                const active = activeNav === label;
                return (
                  <button key={label} onClick={() => { setActiveNav(label); setMenuOpen(false); }}
                    className="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-left transition-colors"
                    style={{ background: active ? C.bgAlt : "transparent", color: active ? C.purpleDark : C.textMuted }}>
                    <Icon size={16} />
                    {label}
                  </button>
                );
              })}
            </nav>
            <div className="px-5 py-4" style={{ borderTop: `1px solid ${C.border}` }}>
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: C.purple }}>
                  <User size={16} className="text-white" />
                </div>
                <div>
                  <div className="text-sm font-semibold" style={{ color: C.text }}>Admin</div>
                  <div className="text-xs" style={{ color: C.textFaint }}>admin@zeaisoft.com</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Main ── */}
      <main className="flex-1 px-4 md:px-8 py-5 md:py-6 max-w-screen-2xl w-full mx-auto">

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-5 md:mb-6">
          <div>
            <h1 className="text-xl md:text-2xl font-semibold" style={{ color: C.text }}>FAQ Management</h1>
            <p className="text-xs md:text-sm mt-0.5" style={{ color: C.textMuted }}>
              Manage frequently asked questions used by the AI chatbot
            </p>
          </div>
          <button
            className="flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors shadow-sm shrink-0 self-start sm:self-auto text-white"
            style={{ background: C.purple }}>
            <Plus size={15} />Add FAQ
          </button>
        </div>

        {/* Stat Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-5 md:mb-6">
          {[
            { bg: C.purpleDark, icon: HelpCircle,   count: 22, label: "Total FAQs" },
            { bg: C.success,    icon: CheckCircle2,  count: 18, label: "Active" },
            { bg: C.warning,    icon: FileText,      count: 3,  label: "Draft" },
            { bg: C.purple,     icon: Archive,       count: 1,  label: "Archived" },
          ].map(({ bg, icon: Icon, count, label }) => (
            <div key={label} className="rounded-xl p-4 md:p-5 text-white flex items-center gap-3 md:gap-4 shadow-sm" style={{ background: bg }}>
              <div className="w-9 h-9 md:w-10 md:h-10 rounded-lg flex items-center justify-center shrink-0" style={{ background: "rgba(255,255,255,0.15)" }}>
                <Icon size={18} className="text-white" />
              </div>
              <div>
                <div className="text-2xl md:text-3xl font-bold">{count}</div>
                <div className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.75)" }}>{label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Table Card */}
        <div className="rounded-xl shadow-sm overflow-hidden" style={{ background: C.panel, border: `1px solid ${C.border}` }}>

          {/* Filters */}
          <div className="flex flex-col gap-3 px-4 md:px-5 py-4" style={{ borderBottom: `1px solid ${C.border}`, background: `linear-gradient(to right, ${C.bgAlt}, ${C.bg}88)` }}>
            <div className="relative w-full">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: C.purple }} />
              <input
                type="text"
                placeholder="Search FAQs..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-sm rounded-lg focus:outline-none transition-colors shadow-sm"
                style={{ background: C.panel, border: `1px solid ${C.borderStrong}`, color: C.text }}
              />
            </div>
            <div className="flex items-center gap-2 overflow-x-auto hide-scrollbar pb-0.5">
              {CATS.map((cat) => {
                const active = category === cat;
                const pill = CATEGORY_PILL_STYLE[cat];
                return (
                  <button
                    key={cat}
                    onClick={() => setCategory(cat)}
                    className="text-xs font-medium px-3 py-1.5 rounded-full border whitespace-nowrap shrink-0 transition-colors"
                    style={active
                      ? { background: C.purple, color: "#fff", borderColor: C.purple }
                      : pill
                        ? { background: pill.bg, color: pill.text, borderColor: pill.border }
                        : { background: C.panelSolid, color: C.textMuted, borderColor: C.border }
                    }>
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Desktop Table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr style={{ background: C.purpleDark, borderBottom: `1px solid ${C.purpleDark}` }}>
                  {["Question", "Category", "Answer Preview", "Last Updated", "Status", "Actions"].map((h) => (
                    <th key={h} className="text-left px-4 py-3 text-xs font-semibold uppercase tracking-wider whitespace-nowrap first:pl-5"
                      style={{ color: "rgba(255,255,255,0.65)" }}>
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((faq, i) => (
                  <tr key={i} className="group transition-colors border-l-4"
                    style={{ borderLeftColor: CATEGORY_BORDER[faq.category] ?? C.border, borderBottom: `1px solid ${C.border}` }}
                    onMouseEnter={e => (e.currentTarget.style.background = C.panelSolid)}
                    onMouseLeave={e => (e.currentTarget.style.background = "transparent")}>
                    <td className="pl-5 pr-4 py-3.5 font-medium max-w-[220px]" style={{ color: C.text }}>{faq.question}</td>
                    <td className="px-4 py-3.5">
                      {(() => {
                        const s = CATEGORY_STYLES[faq.category];
                        return s
                          ? <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium" style={{ background: s.bg, color: s.text }}>{faq.category}</span>
                          : <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium" style={{ background: C.panelSolid, color: C.textMuted }}>{faq.category}</span>;
                      })()}
                    </td>
                    <td className="px-4 py-3.5 max-w-[280px] truncate" style={{ color: C.textMuted }}>{faq.preview}</td>
                    <td className="px-4 py-3.5 whitespace-nowrap" style={{ color: C.textMuted }}>{faq.updated}</td>
                    <td className="px-4 py-3.5">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold"
                        style={faq.status === "Active"
                          ? { background: "rgba(5,150,105,0.12)", color: C.success }
                          : { background: "rgba(217,119,6,0.12)", color: C.warning }}>
                        {faq.status}
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1 rounded transition-colors" style={{ color: C.textFaint }}
                          onMouseEnter={e => (e.currentTarget.style.color = C.purple)}
                          onMouseLeave={e => (e.currentTarget.style.color = C.textFaint)}>
                          <Pencil size={14} />
                        </button>
                        <button className="p-1 rounded transition-colors" style={{ color: C.textFaint }}
                          onMouseEnter={e => (e.currentTarget.style.color = C.danger)}
                          onMouseLeave={e => (e.currentTarget.style.color = C.textFaint)}>
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr><td colSpan={6} className="px-5 py-10 text-center text-sm" style={{ color: C.textFaint }}>No FAQs found matching your search.</td></tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Mobile Cards */}
          <div className="md:hidden">
            {filtered.length === 0 && (
              <p className="px-4 py-10 text-center text-sm" style={{ color: C.textFaint }}>No FAQs found matching your search.</p>
            )}
            {filtered.map((faq, i) => (
              <div key={i} className="px-4 py-4 border-l-4" style={{ borderLeftColor: CATEGORY_BORDER[faq.category] ?? C.border, borderBottom: `1px solid ${C.border}` }}>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <p className="text-sm font-semibold leading-snug flex-1" style={{ color: C.text }}>{faq.question}</p>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button className="p-1.5 rounded transition-colors" style={{ color: C.textFaint }}><Pencil size={13} /></button>
                    <button className="p-1.5 rounded transition-colors" style={{ color: C.textFaint }}><Trash2 size={13} /></button>
                  </div>
                </div>
                <p className="text-xs mb-3 line-clamp-2" style={{ color: C.textMuted }}>{faq.preview}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {(() => {
                      const s = CATEGORY_STYLES[faq.category];
                      return <span className="inline-flex px-2 py-0.5 rounded-full text-xs font-medium" style={s ? { background: s.bg, color: s.text } : { background: C.panelSolid, color: C.textMuted }}>{faq.category}</span>;
                    })()}
                    <span className="inline-flex px-2 py-0.5 rounded-full text-xs font-semibold"
                      style={faq.status === "Active"
                        ? { background: "rgba(5,150,105,0.12)", color: C.success }
                        : { background: "rgba(217,119,6,0.12)", color: C.warning }}>
                      {faq.status}
                    </span>
                  </div>
                  <span className="text-xs" style={{ color: C.textFaint }}>{faq.updated}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between px-4 md:px-5 py-3.5 flex-wrap gap-2" style={{ borderTop: `1px solid ${C.border}` }}>
            <span className="text-xs" style={{ color: C.textMuted }}>Showing 1–10 of 22 FAQs</span>
            <div className="flex items-center gap-2 md:gap-3">
              <div className="hidden sm:flex items-center gap-1.5 text-xs" style={{ color: C.textMuted }}>
                <span>Rows:</span>
                <select className="rounded px-1.5 py-0.5 text-xs focus:outline-none"
                  style={{ border: `1px solid ${C.border}`, background: C.panelSolid, color: C.text }}>
                  <option>10</option><option>20</option><option>50</option>
                </select>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} disabled={currentPage === 1}
                  className="p-1 rounded disabled:opacity-30 transition-colors" style={{ color: C.textMuted }}>
                  <ChevronLeft size={15} />
                </button>
                {[1, 2, 3].map((page) => (
                  <button key={page} onClick={() => setCurrentPage(page)}
                    className="w-7 h-7 rounded text-xs font-medium transition-colors"
                    style={currentPage === page
                      ? { background: C.purple, color: "#fff" }
                      : { color: C.textMuted }}>
                    {page}
                  </button>
                ))}
                <button onClick={() => setCurrentPage((p) => Math.min(3, p + 1))} disabled={currentPage === 3}
                  className="p-1 rounded disabled:opacity-30 transition-colors" style={{ color: C.textMuted }}>
                  <ChevronRight size={15} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      <style>{`
        .hide-scrollbar::-webkit-scrollbar { display: none; }
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .line-clamp-2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
      `}</style>
    </div>
  );
}
