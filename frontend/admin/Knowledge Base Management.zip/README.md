
  # Knowledge Base Management

  This is a code bundle for Knowledge Base Management. The original project is available at https://www.figma.com/design/PQfTLD45Bu0EHlcLuR8m0d/Knowledge-Base-Management.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  