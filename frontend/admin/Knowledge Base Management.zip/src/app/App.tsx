import { useState } from "react";
import {
  Bell, ChevronDown, Upload, FileText, CheckCircle, Clock, Cpu,
  UploadCloud, Eye, RefreshCw, Layers, RotateCcw, Trash2,
  LayoutDashboard, HelpCircle, BookOpen, Building2, MessageSquare,
  BarChart2, Settings, Menu, X,
} from "lucide-react";
import zeaisoftLogo from "@/imports/zeaisoft_logo.jpg";

const C = {
  bg:          "#D0BDF4",
  bgAlt:       "#DCCEF8",
  panel:       "#FFFFFF",
  panelSolid:  "#F6F0FE",
  border:      "rgba(91,33,182,0.16)",
  borderStrong:"rgba(91,33,182,0.4)",
  purple:      "#8B5CF6",
  purpleLight: "#7C3AED",
  purpleDark:  "#5B21B6",
  cyan:        "#0891B2",
  pink:        "#DB2777",
  text:        "#241B3D",
  textMuted:   "#6B6480",
  textFaint:   "#8F86A8",
  success:     "#059669",
  warning:     "#D97706",
  danger:      "#DC2626",
};

const NAV_ITEMS = [
  { label: "Dashboards",         icon: LayoutDashboard },
  { label: "FAQ Management",     icon: HelpCircle },
  { label: "Knowledge Base",     icon: BookOpen },
  { label: "Company Information",icon: Building2 },
  { label: "Chat history",       icon: MessageSquare },
  { label: "Analytics",          icon: BarChart2 },
  { label: "Settings",           icon: Settings },
];

const STATS = [
  {
    label: "Total Documents", value: 5, icon: FileText,
    bg: C.purple, sub: "rgba(255,255,255,0.75)",
  },
  {
    label: "Processed", value: 2, icon: CheckCircle,
    bg: C.success, sub: "rgba(255,255,255,0.75)",
  },
  {
    label: "Pending", value: 1, icon: Clock,
    bg: C.warning, sub: "rgba(255,255,255,0.75)",
  },
  {
    label: "Embeddings Generated", value: 2, icon: Cpu,
    bg: C.purpleDark, sub: "rgba(255,255,255,0.75)",
  },
];

type DocStatus = "Embedded" | "Processing" | "Pending" | "Failed";

interface Document {
  id: number; name: string; type: string;
  uploadDate: string; uploadTime: string;
  status: DocStatus; progress: number;
}

const DOCUMENTS: Document[] = [
  { id: 1, name: "ZeAI Self-Internship Guide.pdf",    type: "PDF",  uploadDate: "May 30, 2025", uploadTime: "03:11 AM", status: "Embedded",   progress: 100 },
  { id: 2, name: "Training Programme Overview.docx",  type: "DOCX", uploadDate: "May 30, 2025", uploadTime: "03:11 AM", status: "Processing", progress: 60  },
  { id: 3, name: "HR Handbook v2.pdf",                type: "PDF",  uploadDate: "May 17, 2025", uploadTime: "10:45 AM", status: "Embedded",   progress: 100 },
  { id: 4, name: "Company Policies.pdf",              type: "PDF",  uploadDate: "May 12, 2025", uploadTime: "02:30 PM", status: "Pending",    progress: 0   },
  { id: 5, name: "ZeAI Self-Booklet.pdf",             type: "PDF",  uploadDate: "May 10, 2025", uploadTime: "03:45 PM", status: "Processing", progress: 35  },
];

const STATUS_META: Record<DocStatus, { bg: string; color: string; label: string }> = {
  Embedded:   { bg: "#D1FAE5", color: C.success,     label: "Embedded"   },
  Processing: { bg: "#FEF3C7", color: C.warning,     label: "Processing" },
  Pending:    { bg: "#EDE9FE", color: C.purpleLight,  label: "Pending"    },
  Failed:     { bg: "#FEE2E2", color: C.danger,       label: "Failed"     },
};

const PROGRESS_COLOR: Record<DocStatus, string> = {
  Embedded:   C.success,
  Processing: C.warning,
  Pending:    C.purple,
  Failed:     C.danger,
};

export default function App() {
  const [activeNav, setActiveNav] = useState("Knowledge Base");
  const [isDragging, setIsDragging] = useState(false);
  const [menuOpen, setMenuOpen]   = useState(false);

  return (
    <div className="min-h-screen font-[Inter,sans-serif]" style={{ background: C.bg }}>

      {/* ── Navbar ── */}
      <header
        className="sticky top-0 z-40 shadow-sm"
        style={{ background: C.panel, borderBottom: `1px solid ${C.border}` }}
      >
        <div className="flex items-center h-14 px-4 gap-3">

          {/* Logo */}
          <div className="flex-shrink-0">
            <img src={zeaisoftLogo} alt="ZeAISoft logo" className="h-9 object-contain" />
          </div>

          <div className="hidden md:block h-6 w-px flex-shrink-0" style={{ background: C.border }} />

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-0.5 flex-1 overflow-x-auto scrollbar-hide">
            {NAV_ITEMS.map(({ label, icon: Icon }) => {
              const isActive = activeNav === label;
              return (
                <button
                  key={label}
                  onClick={() => setActiveNav(label)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm whitespace-nowrap transition-all font-medium"
                  style={
                    isActive
                      ? { background: C.purple, color: "#fff" }
                      : { color: C.textMuted }
                  }
                  onMouseEnter={e => { if (!isActive) { e.currentTarget.style.color = C.purple; e.currentTarget.style.background = C.panelSolid; } }}
                  onMouseLeave={e => { if (!isActive) { e.currentTarget.style.color = C.textMuted; e.currentTarget.style.background = "transparent"; } }}
                >
                  <Icon size={14} />
                  {label}
                </button>
              );
            })}
          </nav>

          <div className="flex-1 md:hidden" />

          {/* Right */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <button className="relative p-2 rounded-full transition-colors" style={{ color: C.purple }}
              onMouseEnter={e => (e.currentTarget.style.background = C.panelSolid)}
              onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
            >
              <Bell size={18} />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full" style={{ background: C.warning }} />
            </button>

            <button
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg border text-sm font-medium transition-colors"
              style={{ color: C.purple, borderColor: C.borderStrong }}
              onMouseEnter={e => (e.currentTarget.style.background = C.panelSolid)}
              onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
            >
              <div className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold" style={{ background: C.purple }}>A</div>
              Admin
              <ChevronDown size={13} style={{ color: C.textFaint }} />
            </button>

            <button
              className="md:hidden p-2 rounded-lg transition-colors"
              style={{ color: C.purple }}
              onClick={() => setMenuOpen(v => !v)}
              onMouseEnter={e => (e.currentTarget.style.background = C.panelSolid)}
              onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
            >
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile drawer */}
        {menuOpen && (
          <div className="md:hidden px-4 py-3 flex flex-col gap-1" style={{ borderTop: `1px solid ${C.border}`, background: C.panel }}>
            {NAV_ITEMS.map(({ label, icon: Icon }) => {
              const isActive = activeNav === label;
              return (
                <button
                  key={label}
                  onClick={() => { setActiveNav(label); setMenuOpen(false); }}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-left transition-colors"
                  style={isActive ? { background: C.purple, color: "#fff" } : { color: C.text }}
                >
                  <Icon size={16} />
                  {label}
                </button>
              );
            })}
            <div className="mt-2 pt-2 flex items-center gap-2 px-3" style={{ borderTop: `1px solid ${C.border}` }}>
              <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold" style={{ background: C.purple }}>A</div>
              <span className="text-sm font-medium" style={{ color: C.purple }}>Admin</span>
            </div>
          </div>
        )}
      </header>

      {/* ── Main ── */}
      <main className="max-w-7xl mx-auto px-3 sm:px-6 py-5 sm:py-6">

        {/* Page header */}
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-6">
          <div>
            <h1 className="text-lg sm:text-xl font-bold" style={{ color: C.text }}>
              Knowledge Base Management
            </h1>
            <p className="text-xs sm:text-sm mt-0.5" style={{ color: C.textMuted }}>
              Upload and manage documents used by the AI chatbot.
            </p>
          </div>
          <button
            className="flex items-center justify-center gap-2 px-4 py-2.5 text-white text-sm font-semibold rounded-xl hover:opacity-90 shadow-md w-full sm:w-auto transition-opacity"
            style={{ background: `linear-gradient(135deg, ${C.purple}, ${C.purpleDark})` }}
          >
            <Upload size={14} />
            Upload Document
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
          {STATS.map(({ label, value, icon: Icon, bg, sub }) => (
            <div key={label} className="rounded-2xl p-4 sm:p-5 flex items-center gap-3 sm:gap-4 shadow-md" style={{ background: bg }}>
              <div className="p-2 sm:p-2.5 rounded-xl flex-shrink-0" style={{ background: "rgba(255,255,255,0.2)" }}>
                <Icon size={20} className="text-white" />
              </div>
              <div className="min-w-0">
                <p className="text-2xl sm:text-3xl font-bold text-white">{value}</p>
                <p className="text-xs mt-0.5 font-medium leading-tight" style={{ color: sub }}>{label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Upload + Status */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4 mb-6">

          {/* Drop zone */}
          <div
            className="lg:col-span-2 rounded-2xl border-2 border-dashed flex flex-col items-center justify-center py-10 sm:py-12 px-6 cursor-pointer transition-all"
            style={{
              borderColor: isDragging ? C.purple : C.borderStrong,
              background: isDragging ? C.bgAlt : C.panel,
            }}
            onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={() => setIsDragging(false)}
          >
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mb-4 shadow-inner" style={{ background: C.panelSolid }}>
              <UploadCloud size={28} style={{ color: C.purple }} />
            </div>
            <p className="text-sm font-semibold mb-1" style={{ color: C.text }}>Drag & drop files here</p>
            <p className="text-xs mb-1" style={{ color: C.textMuted }}>Or click to browse</p>
            <p className="text-xs text-center" style={{ color: C.textFaint }}>Supports PDF, DOCX, TXT · max 50 MB per file</p>
          </div>

          {/* Status panel */}
          <div
            className="rounded-2xl border p-4 sm:p-5 flex flex-col gap-4"
            style={{ background: C.panelSolid, borderColor: C.border }}
          >
            <div>
              <p className="text-sm font-bold mb-2" style={{ color: C.text }}>Upload Status</p>
              <div className="flex items-center gap-2 text-xs" style={{ color: C.textMuted }}>
                <CheckCircle size={14} style={{ color: C.success }} />
                No files uploading
              </div>
            </div>
            <div>
              <p className="text-sm font-bold mb-2" style={{ color: C.text }}>Allowed File Types</p>
              <div className="flex flex-wrap gap-2">
                {["PDF", "TXT", "DOCX"].map(t => (
                  <span key={t} className="px-3 py-1 text-xs font-semibold rounded-full text-white" style={{ background: C.purple }}>
                    {t}
                  </span>
                ))}
              </div>
            </div>
            <p className="text-xs mt-auto" style={{ color: C.textFaint }}>Max file size: 50 MB</p>
          </div>
        </div>

        {/* ── Desktop table ── */}
        <div className="hidden md:block rounded-2xl overflow-hidden shadow-md" style={{ border: `1px solid ${C.border}` }}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr style={{ background: `linear-gradient(90deg, ${C.purple}, ${C.purpleDark})` }}>
                  {["Document Name", "File Type", "Upload Date", "Status", "Progress", "Actions"].map(h => (
                    <th key={h} className="text-left px-5 py-3.5 text-xs font-semibold text-white uppercase tracking-wide whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {DOCUMENTS.map((doc, i) => {
                  const meta = STATUS_META[doc.status];
                  const rowBg = i % 2 === 0 ? C.panel : C.panelSolid;
                  return (
                    <tr
                      key={doc.id}
                      className="transition-colors"
                      style={{ background: rowBg, borderTop: `1px solid ${C.border}` }}
                      onMouseEnter={e => (e.currentTarget.style.background = C.bgAlt)}
                      onMouseLeave={e => (e.currentTarget.style.background = rowBg)}
                    >
                      {/* Name */}
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: C.panelSolid }}>
                            <FileText size={15} style={{ color: C.purple }} />
                          </div>
                          <span className="font-medium truncate max-w-[220px]" style={{ color: C.text }}>{doc.name}</span>
                        </div>
                      </td>

                      {/* Type */}
                      <td className="px-4 py-3.5">
                        <span className="px-2.5 py-1 text-xs font-bold rounded-lg" style={{ background: C.panelSolid, color: C.purpleLight }}>
                          {doc.type}
                        </span>
                      </td>

                      {/* Date */}
                      <td className="px-4 py-3.5">
                        <div className="text-xs font-semibold" style={{ color: C.text }}>{doc.uploadDate}</div>
                        <div className="text-xs" style={{ color: C.textFaint }}>{doc.uploadTime}</div>
                      </td>

                      {/* Status */}
                      <td className="px-4 py-3.5">
                        <span className="px-2.5 py-1 rounded-full text-xs font-semibold" style={{ background: meta.bg, color: meta.color }}>
                          {meta.label}
                        </span>
                      </td>

                      {/* Progress */}
                      <td className="px-4 py-3.5">
                        <div className="flex items-center gap-2">
                          <div className="w-24 h-2 rounded-full overflow-hidden" style={{ background: C.bgAlt }}>
                            <div className="h-full rounded-full transition-all" style={{ width: `${doc.progress}%`, background: PROGRESS_COLOR[doc.status] }} />
                          </div>
                          <span className="text-xs font-medium w-8" style={{ color: C.textMuted }}>{doc.progress}%</span>
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3.5">
                        <div className="flex items-center gap-0.5">
                          <Btn icon={Eye}       tip="View"       color={C.purple}      hover={C.panelSolid} />
                          <Btn icon={RefreshCw} tip="Process"    color={C.cyan}        hover="#ECFEFF" />
                          <Btn icon={Layers}    tip="Embeddings" color={C.purpleLight}  hover={C.panelSolid} />
                          <Btn icon={RotateCcw} tip="Sync"       color={C.success}     hover="#D1FAE5" />
                          <Btn icon={Trash2}    tip="Delete"     color={C.danger}      hover="#FEE2E2" />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="px-5 py-3" style={{ borderTop: `1px solid ${C.border}`, background: C.bgAlt }}>
            <p className="text-xs font-semibold" style={{ color: C.textMuted }}>Showing all 5 documents</p>
          </div>
        </div>

        {/* ── Mobile cards ── */}
        <div className="md:hidden flex flex-col gap-3">
          <div className="rounded-2xl px-4 py-3 text-xs font-semibold text-white" style={{ background: `linear-gradient(90deg, ${C.purple}, ${C.purpleDark})` }}>
            All Documents (5)
          </div>
          {DOCUMENTS.map(doc => {
            const meta = STATUS_META[doc.status];
            return (
              <div key={doc.id} className="rounded-2xl p-4 shadow-sm" style={{ background: C.panel, border: `1px solid ${C.border}` }}>
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: C.panelSolid }}>
                    <FileText size={16} style={{ color: C.purple }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold leading-tight truncate" style={{ color: C.text }}>{doc.name}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="px-2 py-0.5 text-xs font-bold rounded-md" style={{ background: C.panelSolid, color: C.purpleLight }}>{doc.type}</span>
                      <span className="px-2 py-0.5 rounded-full text-xs font-semibold" style={{ background: meta.bg, color: meta.color }}>{meta.label}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <p className="text-xs font-semibold" style={{ color: C.text }}>{doc.uploadDate}</p>
                    <p className="text-xs" style={{ color: C.textFaint }}>{doc.uploadTime}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-2 rounded-full overflow-hidden" style={{ background: C.bgAlt }}>
                      <div className="h-full rounded-full" style={{ width: `${doc.progress}%`, background: PROGRESS_COLOR[doc.status] }} />
                    </div>
                    <span className="text-xs font-semibold" style={{ color: C.textMuted }}>{doc.progress}%</span>
                  </div>
                </div>
                <div className="flex items-center gap-0.5 pt-2" style={{ borderTop: `1px solid ${C.border}` }}>
                  <Btn icon={Eye}       tip="View"       color={C.purple}      hover={C.panelSolid} />
                  <Btn icon={RefreshCw} tip="Process"    color={C.cyan}        hover="#ECFEFF" />
                  <Btn icon={Layers}    tip="Embeddings" color={C.purpleLight}  hover={C.panelSolid} />
                  <Btn icon={RotateCcw} tip="Sync"       color={C.success}     hover="#D1FAE5" />
                  <Btn icon={Trash2}    tip="Delete"     color={C.danger}      hover="#FEE2E2" />
                </div>
              </div>
            );
          })}
          <p className="text-xs font-semibold text-center pb-2" style={{ color: C.textMuted }}>Showing all 5 documents</p>
        </div>

      </main>
    </div>
  );
}

function Btn({ icon: Icon, tip, color, hover }: {
  icon: React.ElementType; tip: string; color: string; hover: string;
}) {
  return (
    <button
      title={tip}
      className="p-2 rounded-lg transition-colors"
      style={{ color }}
      onMouseEnter={e => (e.currentTarget.style.background = hover)}
      onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
    >
      <Icon size={15} />
    </button>
  );
}
